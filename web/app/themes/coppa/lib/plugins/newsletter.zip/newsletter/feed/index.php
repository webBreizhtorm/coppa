<div class="wrap">

    <?php include NEWSLETTER_DIR . '/header-new.php'; ?>

    <h5>Feed by Mail</h5>

    <div class="updated">
        <p>
            The Feed by Mail demo has been removed to make the plugin <strong>faster</strong>. You can install the demo separately getting it
            from <a href="http://www.thenewsletterplugin.com/downloads/demos" target="_blank">here</a> or directly the full version from
            <a href="http://www.thenewsletterplugin.com/downloads" target="_blank">here</a>.
        </p>
    </div>

</div>