<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://www.breizhtorm.fr
 * @since      1.0.0
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 * @author     Breizhtorm <web@breizhtorm.fr>
 */
class Wordpress_Breizhtorm_Utils_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'wordpress-breizhtorm-utils',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
