<?php

/**
 * Fired during plugin activation
 *
 * @link       http://www.breizhtorm.fr
 * @since      1.0.0
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 * @author     Breizhtorm <web@breizhtorm.fr>
 */
class Wordpress_Breizhtorm_Utils_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		// Roles & users management
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wordpress-breizhtorm-utils-users-roles.php';
		Wordpress_Breizhtorm_Utils_Users_Roles::create_special_roles();

	}

}
