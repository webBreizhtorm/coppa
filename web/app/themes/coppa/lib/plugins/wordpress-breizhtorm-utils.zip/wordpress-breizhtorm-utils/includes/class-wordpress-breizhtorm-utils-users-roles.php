<?php

/**
 * Roles & users functions
 *
 *
 * @link       http://www.breizhtorm.fr
 * @since      1.0.2
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 */

/**
 * Roles & users management
 *
 *
 * @since      1.0.2
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 * @author     Breizhtorm <web@breizhtorm.fr>
 */
class Wordpress_Breizhtorm_Utils_Users_Roles {


	/**
	 * Adding new role & own filters
	 *
	 * @since    1.0.2
	 */
	public function __construct() {

	}

	/**
	 * Adding new roles
	 *
	 * @since    1.0.2
	 */
	public static function create_special_roles(){

		// Getting editor capabilities
		$editor_role = get_role( 'editor' );
		$editor_caps = $editor_role->capabilities;

		// Creating webmaster role
		add_role( 'webmaster', __('Webmaster', 'wordpress-breizhtorm-utils'), $editor_caps );
		$webmaster_role = get_role( 'webmaster' );

		// Webmaster can edit theme options
		$webmaster_role->add_cap( 'edit_theme_options' );
		
		// Webmaster can edit settings options
		//$webmaster_role->add_cap( 'manage_options' );

		// Webmaster can create/edit users
		$webmaster_role->add_cap( 'list_users' );
		$webmaster_role->add_cap( 'create_users' );
		$webmaster_role->add_cap( 'delete_users' );
		$webmaster_role->add_cap( 'edit_users' );
		$webmaster_role->add_cap( 'promote_users' );

		// Webmaster can manage Woocommerce products & settings
		$webmaster_role->add_cap("manage_woocommerce");
	    $webmaster_role->add_cap("view_woocommerce_reports");
	    $webmaster_role->add_cap("edit_product");
	    $webmaster_role->add_cap("read_product");
	    $webmaster_role->add_cap("delete_product");
	    $webmaster_role->add_cap("edit_products");
	    $webmaster_role->add_cap("edit_others_products");
	    $webmaster_role->add_cap("publish_products");
	    $webmaster_role->add_cap("read_private_products");
	    $webmaster_role->add_cap("delete_products");
	    $webmaster_role->add_cap("delete_private_products");
	    $webmaster_role->add_cap("delete_published_products");
	    $webmaster_role->add_cap("delete_others_products");
	    $webmaster_role->add_cap("edit_private_products");
	    $webmaster_role->add_cap("edit_published_products");
	    $webmaster_role->add_cap("manage_product_terms");
	    $webmaster_role->add_cap("edit_product_terms");
	    $webmaster_role->add_cap("delete_product_terms");
	    $webmaster_role->add_cap("assign_product_terms");
	    $webmaster_role->add_cap("edit_shop_order");
	    $webmaster_role->add_cap("read_shop_order");
	    $webmaster_role->add_cap("delete_shop_order");
	    $webmaster_role->add_cap("edit_shop_orders");
	    $webmaster_role->add_cap("edit_others_shop_orders");
	    $webmaster_role->add_cap("publish_shop_orders");
	    $webmaster_role->add_cap("read_private_shop_orders");
	    $webmaster_role->add_cap("delete_shop_orders");
	    $webmaster_role->add_cap("delete_private_shop_orders");
	    $webmaster_role->add_cap("delete_published_shop_orders");
	    $webmaster_role->add_cap("delete_others_shop_orders");
	    $webmaster_role->add_cap("edit_private_shop_orders");
	    $webmaster_role->add_cap("edit_published_shop_orders");
	    $webmaster_role->add_cap("manage_shop_order_terms");
	    $webmaster_role->add_cap("edit_shop_order_terms");
	    $webmaster_role->add_cap("delete_shop_order_terms");
	    $webmaster_role->add_cap("assign_shop_order_terms");
	    $webmaster_role->add_cap("edit_shop_coupon");
	    $webmaster_role->add_cap("read_shop_coupon");
	    $webmaster_role->add_cap("delete_shop_coupon");
	    $webmaster_role->add_cap("edit_shop_coupons");
	    $webmaster_role->add_cap("edit_others_shop_coupons");
	    $webmaster_role->add_cap("publish_shop_coupons");
	    $webmaster_role->add_cap("read_private_shop_coupons");
	    $webmaster_role->add_cap("delete_shop_coupons");
	    $webmaster_role->add_cap("delete_private_shop_coupons");
	    $webmaster_role->add_cap("delete_published_shop_coupons");
	    $webmaster_role->add_cap("delete_others_shop_coupons");
	    $webmaster_role->add_cap("edit_private_shop_coupons");
	    $webmaster_role->add_cap("edit_published_shop_coupons");
	    $webmaster_role->add_cap("manage_shop_coupon_terms");
	    $webmaster_role->add_cap("edit_shop_coupon_terms");
	    $webmaster_role->add_cap("delete_shop_coupon_terms");
	    $webmaster_role->add_cap("assign_shop_coupon_terms");
	    $webmaster_role->add_cap("edit_shop_webhook");
	    $webmaster_role->add_cap("read_shop_webhook");
	    $webmaster_role->add_cap("delete_shop_webhook");
	    $webmaster_role->add_cap("edit_shop_webhooks");
	    $webmaster_role->add_cap("edit_others_shop_webhooks");
	    $webmaster_role->add_cap("publish_shop_webhooks");
	    $webmaster_role->add_cap("read_private_shop_webhooks");
	    $webmaster_role->add_cap("delete_shop_webhooks");
	    $webmaster_role->add_cap("delete_private_shop_webhooks");
	    $webmaster_role->add_cap("delete_published_shop_webhooks");
	    $webmaster_role->add_cap("delete_others_shop_webhooks");
	    $webmaster_role->add_cap("edit_private_shop_webhooks");
	    $webmaster_role->add_cap("edit_published_shop_webhooks");
	    $webmaster_role->add_cap("manage_shop_webhook_terms");
	    $webmaster_role->add_cap("edit_shop_webhook_terms");
	    $webmaster_role->add_cap("delete_shop_webhook_terms");
	    $webmaster_role->add_cap("assign_shop_webhook_terms");
		
	}

	/**
	 * Removing new roles
	 *
	 * @since    1.0.2
	 */
	public static function remove_special_roles(){

		// Remove Webmaster role
		if( get_role('webmaster') ){
		      remove_role( 'webmaster' );
		}
	}

	/**
	 * Applying limitations to new roles
	 *
	 * @since    1.0.2
	 */
	public function apply_roles_limitations(){

		// Applying filters
		add_filter( 'editable_roles', array(&$this, 'editable_roles'));
		add_filter( 'map_meta_cap', array(&$this, 'map_meta_cap'),10,4);
	}

	/**
	 * Remove 'Administrator' from the list of roles if the current user is not an admin
	 *
	 * @since    1.0.2
	 */
	function editable_roles( $roles ){
		if( isset( $roles['administrator'] ) && !current_user_can('administrator') ){
			unset( $roles['administrator']);
		}
		return $roles;
	}

	/**
	 * If someone is trying to edit or delete an admin, and that user isn't an admin, don't allow it
	 *
	 * @since    1.0.2
	 */
	function map_meta_cap( $caps, $cap, $user_id, $args ){

		switch( $cap ){
			case 'edit_user':
			case 'remove_user':
			case 'promote_user':
				if( isset($args[0]) && $args[0] == $user_id )
					break;
				elseif( !isset($args[0]) )
					$caps[] = 'do_not_allow';
					$other = new WP_User( absint($args[0]) );
					if( $other->has_cap( 'administrator' ) ){
						if(!current_user_can('administrator')){
							$caps[] = 'do_not_allow';
						}
					}
					break;

			case 'delete_user':
			case 'delete_users':
				if( !isset($args[0]) )
					break;
				$other = new WP_User( absint($args[0]) );
				if( $other->has_cap( 'administrator' ) ){
					if(!current_user_can('administrator')){
						$caps[] = 'do_not_allow';
					}
				}
				break;

			default:
				break;
		}

		return $caps;
	}

}
