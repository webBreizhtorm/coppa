=== Plugin Name ===
Contributors: breizhtorm
Donate link: http://www.breizhtorm.fr
Tags: admin, customisation
Requires at least: 3.0.1
Tested up to: 4.7
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Breizhtorm Wordpress utilities

== Description ==

Features:

*   Custom login page logo
*   Custom admin footer
*   Wordpress version hidden
*   Webmaster role : same capabilities as editors, but can manage users, theme options and Woocommerce
*	Move Yoast SEO Meta box at the bottom of admin pages by default

== Installation ==

1. Upload `wordpress-breizhtorm-utils.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.5 =
* Woocommerce : webmaster role can now manage Woocommerce products & settings

= 1.0.4 =
* Fix : deprecation warning

= 1.0.3 =
* Move Yoast SEO Meta box at the bottom of admin pages

= 1.0.2 =
* Added 'Webmaster' role (= Editor capabilities + Users & Theme options management)

= 1.1 =
* Hiding wordpress version

= 1.0 =
* Initial version