Breizhtorm Wordpress utils based on http://wppb.me/

# Features

*   Custom login page logo
*   Custom admin footer
*   Wordpress version hidden
*   Webmaster role : same capabilities as editors, but can manage users, theme options and Woocommerce
*	Move Yoast SEO Meta box at the bottom of admin pages by default

## Roles

Webmaster role is created on plugin activation, and deleted on plugin desactivation.