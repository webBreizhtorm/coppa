<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.breizhtorm.fr
 * @since      1.0.0
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/public
 * @author     Breizhtorm <web@breizhtorm.fr>
 */
class Wordpress_Breizhtorm_Utils_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Breizhtorm_Utils_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Breizhtorm_Utils_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wordpress-breizhtorm-utils-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Breizhtorm_Utils_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Breizhtorm_Utils_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wordpress-breizhtorm-utils-public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function custom_login_logo() {

		?>

		<style type="text/css">
			.login h1 a {
			    background-image: url(<?php echo(plugin_dir_url( __FILE__ ));?>images/admin-login-logo.png);
			    background-size: 320px 84px;
			    width: 320px;
			    height: 84px;
			    -webkit-box-shadow: 0 1px 3px rgba(0,0,0,.13);
				box-shadow: 0 1px 3px rgba(0,0,0,.13);
			}
			@media
			only screen and (-webkit-min-device-pixel-ratio: 2),
			only screen and (   min--moz-device-pixel-ratio: 2),
			only screen and (     -o-min-device-pixel-ratio: 2/1),
			only screen and (        min-device-pixel-ratio: 2),
			only screen and (                min-resolution: 192dpi),
			only screen and (                min-resolution: 2dppx) { 
			  .login h1 a {
				    background-image: url(<?php echo(plugin_dir_url( __FILE__ ));?>images/admin-login-logo@2x.png);
				}
			}
		</style>
		<script>
			document.getElementById("login").getElementsByTagName("a")[0].setAttribute('href','http://www.breizhtorm.fr/');
			document.getElementById("login").getElementsByTagName("a")[0].setAttribute('title','Breizhtorm - L\'agence qui vous éclair');
			document.getElementById("login").getElementsByTagName("a")[0].innerHTML = 'Breizhtorm - L\'agence qui vous éclair';
		</script>

		<?php

	}

	/**
	 * Remove Wordpress Version From Header.
	 *
	 * @since    1.0.1
	 */
	public function remove_version_generator() { return '';}

	/**
	 * Encode WP version for security reasons.
	 *
	 * @since    1.0.1
	 */
	private function remove_version_callback($matches) {
		return "ver=".md5(print_r($matches, true)."");
	}

	/**
	 * Check for WP version and apply callback.
	 *
	 * @since    1.0.1
	 */
	public function remove_version($url) {
		return preg_replace_callback("/ver=[^&]*/", array($this, 'remove_version_callback'), $url);
	}
}
