<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://www.breizhtorm.fr
 * @since      1.0.0
 *
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wordpress_Breizhtorm_Utils
 * @subpackage Wordpress_Breizhtorm_Utils/includes
 * @author     Breizhtorm <web@breizhtorm.fr>
 */
class Wordpress_Breizhtorm_Utils_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		// Roles & users management
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wordpress-breizhtorm-utils-users-roles.php';
		Wordpress_Breizhtorm_Utils_Users_Roles::remove_special_roles();

	}

}
